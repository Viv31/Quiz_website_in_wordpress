<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'Quiz_website_wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Yf`EfP_OkA%u<Tr]O7{&kd4j}?9uHnrgn1]X zvrr[p uh#gl.ucS?{Ndi[&KDAb' );
define( 'SECURE_AUTH_KEY',  '(^,=)-7L01>SHL~Fs=t{&-Lqg|Oz|&AT2D(uam|D4FWJ[jCE23Sc1hHFxGoA)r;3' );
define( 'LOGGED_IN_KEY',    '@=?Ggra}SNx9TxyIOp{Q-:6y$vychdQesXWI-z,+D +{G,]<.JjICgeV^dwF~u$1' );
define( 'NONCE_KEY',        '2fAN_lv-.mzBk.L;O~Gke@b!]u>SNjhi|,7#hz1`aoAi }/~;PiFXwc;TzwGZMaP' );
define( 'AUTH_SALT',        ',hmc+6l0c.MYq6 (R_`!@jZnrcE7.cjOJNm7J[UV4gU[-tLe]<KnONu!4`QJ|!Ud' );
define( 'SECURE_AUTH_SALT', 'tgs=?fIyeXt*f/IUV;*n=1~Ap)WGE+Y?v(ZtI)*b{VId9_13wRv,5lp;U#}(lc8<' );
define( 'LOGGED_IN_SALT',   'yoUZKzH7];5OfrjT0iu*.v9:}!Of}vN35Ol7kW^QALH?vm5]tQld2li9`$X!]G2:' );
define( 'NONCE_SALT',       'bNz#h23W^O /UuU?ixd*Z]Kr}gmL)CBj@,>t]_U]7z{x,IEo{q.mI<[HU)3zmCw9' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'vg_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
